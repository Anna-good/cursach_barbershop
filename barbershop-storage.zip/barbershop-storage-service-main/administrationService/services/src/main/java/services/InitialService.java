package services;


public interface InitialService {

    void createEmployeeRole();

    void createAdminRole();

    void createSuperUser();
}
