# Barbershop Storage servise
##Sceenshots are expired!
### Architecture
![Image of Architecture](https://github.com/titovilya/barbershop-storage-service/blob/main/src/architecture.png)

### Entity-Relationship Diagram
![Image of ERD](https://github.com/titovilya/barbershop-storage-service/blob/main/src/ERD.jpg)


### Database Schema
![Image of Schema](https://github.com/titovilya/barbershop-storage-service/blob/main/src/DB_Schema.jpg)
